[player_body]
w = 58h = 78